 <?php $__env->startSection('content'); ?>

<section class="content-header">
	<h1>
		Rooms
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class="active">Rooms</li>
	</ol>
</section>

<section class="content">
	<div class="box box-info">
		<div class="box-header with-border">
			<div class="col-xs-12">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-primary">
					  <i class="fa fa-plus "></i> Add Room
			</button>
			</div>
		</div>
		<div class="box-body">
			<?php if(count($rmType) > 0): ?> 
			<?php $__currentLoopData = $rmType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="col-lg-3 col-xs-6">
				<!-- small box -->
				<div class="small-box bg-blue">
					<div class="inner">
						<h3>150</h3>
						<p><?php echo e($row->roomType); ?></p>
					</div>
					<div class="icon">
						<i class="fa fa-user"></i>
					</div>
					<a href='/listRoom' class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
			<?php endif; ?>
		</div>
	</div>
	<!-- /.row -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontDesk.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>