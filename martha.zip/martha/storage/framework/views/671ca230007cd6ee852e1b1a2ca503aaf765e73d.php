 
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Guest Information
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Guest</li>
  </ol>
</section>
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">
                  <i class="fa fa-plus "></i> Add Guest
                </button>
        </div>
        <div class="box-body">
          <?php if(session('info')): ?>

          <div class="alert alert-success">

            <?php echo e(session('info')); ?>

          </div>
          <?php endif; ?>
          <table id="tbl" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Address</th>
                <th>Contact Number</th>
                <th>Email Address</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($guest) > 0): ?> 
                <?php $__currentLoopData = $guest->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($row['gLastname']); ?></td>
                    <td><?php echo e($row['gFirstname']); ?></td>
                    <td><?php echo e($row['gMiddlename']); ?></td>
                    <td><?php echo e($row['address']); ?></td>
                    <td><?php echo e($row['gContactNumber']); ?></td>
                    <td><?php echo e($row['gEmail']); ?></td>
                    <td style="text-align:center">
                      <button class="btn btn-info" data-gLastname="<?php echo e($row->gLastname); ?>" data-gFirstname="<?php echo e($row->gFirstname); ?>" data-gMiddlename="<?php echo e($row->gMiddlename); ?>" data-address="<?php echo e($row->address); ?>" data-gContactNumber="<?php echo e($row->gContactNumber); ?>" data-gEmail="<?php echo e($row->gEmail); ?>" data-id="<?php echo e($row->id); ?>" data-toggle="modal" data-target="#edit">Edit</button> |
                      <button class="btn btn-danger" data-id="<?php echo e($row->id); ?>" data-toggle="modal" data-target="#delete">Delete</button>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add Guest</h4>
        </div>
        <form method="post" action="<?php echo e(route('guest.store')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="modal-body">
            <?php echo $__env->make('frontDesk.guest.guestForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        
          <div class="modal-footer">
            <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">Save changes</button>
          </div>
        </form>
      </div>  
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  
  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Guest Information</h4>
      </div>
      <form action="<?php echo e(route('guest.update' , 'guest')); ?>" method="post">
      		<?php echo e(method_field('patch')); ?>

      		<?php echo e(csrf_field()); ?>

	      <div class="modal-body">
	      		<input type="hidden" name="guest_id" id="guest_id" value= " ">
				  <?php echo $__env->make('frontDesk.guest.guestForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-success">Save Changes</button>
	      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">Delete Confirmation</h4>
      </div>
      <form action="<?php echo e(route('guest.destroy' , 'guest')); ?>" method="post">
      		<?php echo e(method_field('delete')); ?>

      		<?php echo e(csrf_field()); ?>

	      <div class="modal-body">
				<h3>
                  <p class="text-center">
					Are you sure you want to delete this?
                  </p>
                </h3>
	      		<input type="hidden" name="guest_id" id="guest_id" value= " ">

	      </div>
	      <div class="modal-footer">
          
	        <button type="button" class="btn btn-success pull-left" data-dismiss="modal">No, Cancel</button>
	        <button type="submit" class="btn btn-warning">Yes, Delete</button>
	      </div>
      </form>
    </div>
  </div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontDesk.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>