 
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Confirmed
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Confirmed</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-default">
                <div class="box-body">

                    <table id="tbl" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Check-IN</th>
                                <th>Check-OUT</th>
                                <th>Room Acquired</th>
                                <th>Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($reservation) > 0): ?>
                            
                                <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowReserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                    <?php if($rowReserve->status == 'accepted'): ?>
                                        <tr>
                                            <td><?php echo e($rowReserve->guest->gLastname); ?></td>
                                            <td><?php echo e($rowReserve->guest->gFirstname); ?></td>
                                            <td><?php echo e($rowReserve->checkIn); ?></td>
                                            <td><?php echo e($rowReserve->checkOut); ?></td>
                                            <td><?php echo e($rowReserve->roomTypes->roomType); ?></td>
                                            <td></td>
                                            <td style="text-align:center">
                                                <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#see"><i class="fa fa-user"></i>
                                                </button>
                                                
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontDesk.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>