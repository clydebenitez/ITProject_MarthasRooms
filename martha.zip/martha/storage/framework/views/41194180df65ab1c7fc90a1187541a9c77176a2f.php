 <?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Confirmation List
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Confirmation List</li>
  </ol>
</section>
<section class="content">
  <div class="row">
    <div class="col-xs-12">

      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
          <table id="tbl" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Lastname</th>
                <th>Firstname</th>
                <th>Check-IN</th>
                <th>Check-OUT</th>
                <th>Room Acquired</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                  <button type="button" class="btn btn-danger btn-xs"><i class="fa fa-remove "></i> Check-Out</button>
                </td>
              </tr>



            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontDesk.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>