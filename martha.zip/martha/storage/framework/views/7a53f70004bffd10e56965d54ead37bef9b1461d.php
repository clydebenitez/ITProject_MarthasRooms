 
<?php $__env->startSection('title', '| Make Reservation'); ?> 
<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
        Reservation
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Reservation</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-default">
                <div class="box-header with-border">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">
                  <i class="fa fa-plus "></i> Add Reservation
                </button>
                </div>
                <div class="box-body">

                    <table id="tbl" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Check-IN</th>
                                <th>Check-OUT</th>
                                <th>Room Acquired</th>
                                <th>Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservation->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowReserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <?php if($rowReserve->status != 'canceled' || $rowReserve->status != 'accepted'   ): ?>
                               
               
                            <tr>
                                <td><?php echo e($rowReserve->guest->gLastname); ?></td>
                                <td><?php echo e($rowReserve->guest->gFirstname); ?></td>
                                <td><?php echo e($rowReserve->checkIn); ?></td>
                                <td><?php echo e($rowReserve->checkOut); ?></td>
                                <td><?php echo e($rowReserve->roomTypes->roomType); ?></td>
                                <td><?php echo e($rowReserve->status); ?></td>
                                <td style="text-align:center">
                                    <div class="btn-group">
                                        <div class="row">
                                            
                                            <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#see"><i class="fa fa-user"></i></button>
                                            <button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#cancel"><i class="fa fa-remove"></i></button>
                                            <button class="btn btn-success btn-xs"data-toggle="modal" data-target="#accept"><i class="fa fa-check"></i></button>
                                            
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Reservation</h4>
                </div>
                <form method="post" action="<?php echo e(route('reservation.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-4">
                                    <label for="firstname">Firstname</label>
                                    <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Firstname"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-4">
                                    <label for="middlename">Middlename</label>
                                    <input type="text" class="form-control" name="middlename" id="middlename" placeholder="Middlename"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-4">
                                    <label for="lastname">Lastname</label>
                                    <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Lastname"autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" placeholder="Address"autocomplete="off" autofocus>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Email Address"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="number">Contact Number</label>
                                    <input type="text" class="form-control" name="number" id="number" placeholder="Contact Number" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="room">Type of Room</label>
                                   
                                    
                                    <select class="form-control" name="roomType" id="roomType">
                                        <?php if(count('$roomType') > 0): ?>
                                    
                                        <?php $__currentLoopData = $roomType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <option value="<?php echo e($rowRoom->id); ?>"><?php echo e($rowRoom->roomType); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="in">Check-In</label>
                                    <input type="date" class="form-control" name="in" id="in" autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="out">Check-Out</label>
                                    <input type="date" class="form-control" name="out" id="out" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="adult">Number of Adult</label>
                                    <input type="number" min="0" class="form-control" name="adult" id="adult" autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="children">Number of Children</label>
                                    <input type="number" min="0" class="form-control" name="children" id="children" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-10">
                                <label for="info">Additional Information</label>
                                <textarea class="form-control" name="info" id="info">
                                </textarea>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Cancel</button>
	                   <button type="submit" class="btn btn-success">Reserve</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontDesk.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>