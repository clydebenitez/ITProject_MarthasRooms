<script>

  
  $('#edit').on('show.bs.modal', function (event) {

      var button = $(event.relatedTarget) 
      var lastname = button.data('gLastname') 
      var firstname = button.data('gFirstname') 
      var middlename = button.data('gMiddlename') 
      var address = button.data('address') 
      var contact = button.data('gContactNumber') 
      var email = button.data('gEmail') 
      var id = button.data('id') 
      var modal = $(this)

      modal.find('.modal-body #lastname').val(lastname);
      modal.find('.modal-body #firstname').val(firstname);
      modal.find('.modal-body #middlename').val(middlename);
      modal.find('.modal-body #address').val(address);
      modal.find('.modal-body #contactnumber').val(contact);
      modal.find('.modal-body #email').val(email);
      modal.find('.modal-body #guest_id').val(id);
})


  


</script>
