@extends('frontDesk.main') 
@section('content')
<section class="content-header">
  <h1>
    Guest Information
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Guest</li>
  </ol>
</section>
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-default">
        <div class="box-header with-border">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">
                  <i class="fa fa-plus "></i> Add Guest
                </button>
        </div>
        <div class="box-body">
          @if(session('info'))

          <div class="alert alert-success">

            {{session('info')}}
          </div>
          @endif
          <table id="tbl" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Last Name</th>
                <th>First Name</th>
                <th>Middle Name</th>
                <th>Address</th>
                <th>Contact Number</th>
                <th>Email Address</th>
              </tr>
            </thead>
            <tbody>
              @if(count($guest) > 0) 
                @foreach($guest->all() as $row)
                  <tr>
                    <td>{{$row['gLastname']}}</td>
                    <td>{{$row['gFirstname']}}</td>
                    <td>{{$row['gMiddlename']}}</td>
                    <td>{{$row['address']}}</td>
                    <td>{{$row['gContactNumber']}}</td>
                    <td>{{$row['gEmail']}}</td>
                    <td style="text-align:center">
                      <button class="btn btn-info" data-gLastname="{{$row->gLastname}}" data-gFirstname="{{$row->gFirstname}}" data-gMiddlename="{{$row->gMiddlename}}" data-address="{{$row->address}}" data-gContactNumber="{{$row->gContactNumber}}" data-gEmail="{{$row->gEmail}}" data-id="{{$row->id}}" data-toggle="modal" data-target="#edit">Edit</button> |
                      <button class="btn btn-danger" data-id="{{$row->id}}" data-toggle="modal" data-target="#delete">Delete</button>
                    </td>
                  </tr>
                @endforeach 
              @endif
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-default">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Add Guest</h4>
        </div>
        <form method="post" action="{{route('guest.store')}}">
          {{csrf_field()}}
          <div class="modal-body">
            @include('frontDesk.guest.guestForm')
          </div>
        
          <div class="modal-footer">
            <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">Save changes</button>
          </div>
        </form>
      </div>  
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  
  
  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Guest Information</h4>
      </div>
      <form action="{{route('guest.update' , 'guest')}}" method="post">
      		{{method_field('patch')}}
      		{{csrf_field()}}
	      <div class="modal-body">
	      		<input type="hidden" name="guest_id" id="guest_id" value= " ">
				  @include('frontDesk.guest.guestForm')
	      </div>
	      <div class="modal-footer">
	        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
	        <button type="submit" class="btn btn-success">Save Changes</button>
	      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title text-center" id="myModalLabel">Delete Confirmation</h4>
      </div>
      <form action="{{route('guest.destroy' , 'guest')}}" method="post">
      		{{method_field('delete')}}
      		{{csrf_field()}}
	      <div class="modal-body">
				<h3>
                  <p class="text-center">
					Are you sure you want to delete this?
                  </p>
                </h3>
	      		<input type="hidden" name="guest_id" id="guest_id" value= " ">

	      </div>
	      <div class="modal-footer">
          
	        <button type="button" class="btn btn-success pull-left" data-dismiss="modal">No, Cancel</button>
	        <button type="submit" class="btn btn-warning">Yes, Delete</button>
	      </div>
      </form>
    </div>
  </div>
</div>
</section>
@stop
