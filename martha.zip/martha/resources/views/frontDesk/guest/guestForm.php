<div class="form-group">
    <label for="gLastname">Last Name</label>
    <input type="text" class="form-control" name="lastname" id="lastname" autocomplete="off" autofocus>
</div>

<div class="form-group">
    <label for="gFirstname">First Name</label>
    <input type="text" class="form-control" name="firstname" id="firstname" autocomplete="off">

</div>

<div class="form-group">
    <label for="gMiddlename">Middle Name</label>
    <input type="text" class="form-control" name="middlename" id="middlename" autocomplete="off">
</div>


<div class="form-group">
    <label for="address">Address</label>
    <input type="text" class="form-control" name="address" id="address" autocomplete="off">
</div>

<div class="form-group">
    <label for="gContactNumber">Contact Number</label>
    <input type="text" class="form-control" name="contactnumber" id="contactnumber" autocomplete="off">
</div>

<div class="form-group">
    <label for="gEmail">Email Address</label>
    <input type="text" class="form-control" name="email" id="email" autocomplete="off">
</div>