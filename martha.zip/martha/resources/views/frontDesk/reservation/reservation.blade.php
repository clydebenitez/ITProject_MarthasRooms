@extends('frontDesk.main') 
@section('title', '| Make Reservation') 
@section('content')
<section class="content-header">
    <h1>
        Reservation
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Reservation</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-default">
                <div class="box-header with-border">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-default">
                  <i class="fa fa-plus "></i> Add Reservation
                </button>
                </div>
                <div class="box-body">

                    <table id="tbl" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Check-IN</th>
                                <th>Check-OUT</th>
                                <th>Room Acquired</th>
                                <th>Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            @foreach($reservation->all() as $rowReserve) 
                            @if($rowReserve->status != 'canceled' || $rowReserve->status != 'accepted'   )
                               
               
                            <tr>
                                <td>{{$rowReserve->guest->gLastname}}</td>
                                <td>{{$rowReserve->guest->gFirstname}}</td>
                                <td>{{$rowReserve->checkIn}}</td>
                                <td>{{$rowReserve->checkOut}}</td>
                                <td>{{$rowReserve->roomTypes->roomType}}</td>
                                <td>{{$rowReserve->status}}</td>
                                <td style="text-align:center">
                                    <div class="btn-group">
                                        <div class="row">
                                            
                                            <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#see"><i class="fa fa-user"></i></button>
                                            <button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#cancel"><i class="fa fa-remove"></i></button>
                                            <button class="btn btn-success btn-xs"data-toggle="modal" data-target="#accept"><i class="fa fa-check"></i></button>
                                            
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Add Reservation</h4>
                </div>
                <form method="post" action="{{route('reservation.store')}}">
                    {{csrf_field()}}
                    <div class="modal-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-4">
                                    <label for="firstname">Firstname</label>
                                    <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Firstname"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-4">
                                    <label for="middlename">Middlename</label>
                                    <input type="text" class="form-control" name="middlename" id="middlename" placeholder="Middlename"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-4">
                                    <label for="lastname">Lastname</label>
                                    <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Lastname"autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" name="address" id="address" placeholder="Address"autocomplete="off" autofocus>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Email Address"autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="number">Contact Number</label>
                                    <input type="text" class="form-control" name="number" id="number" placeholder="Contact Number" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="room">Type of Room</label>
                                   
                                    
                                    <select class="form-control" name="roomType" id="roomType">
                                        @if(count('$roomType') > 0)
                                    
                                        @foreach($roomType as $rowRoom) 
                                        <option value="{{$rowRoom->id}}">{{$rowRoom->roomType}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="in">Check-In</label>
                                    <input type="date" class="form-control" name="in" id="in" autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="out">Check-Out</label>
                                    <input type="date" class="form-control" name="out" id="out" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-6">
                                    <label for="adult">Number of Adult</label>
                                    <input type="number" min="0" class="form-control" name="adult" id="adult" autocomplete="off" autofocus>
                                </div>
                                <div class="col-sm-6">
                                    <label for="children">Number of Children</label>
                                    <input type="number" min="0" class="form-control" name="children" id="children" autocomplete="off" autofocus>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-1"></div>
                            <div class="col-sm-10">
                                <label for="info">Additional Information</label>
                                <textarea class="form-control" name="info" id="info">
                                </textarea>
                            </div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Cancel</button>
	                   <button type="submit" class="btn btn-success">Reserve</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>


</section>
@stop