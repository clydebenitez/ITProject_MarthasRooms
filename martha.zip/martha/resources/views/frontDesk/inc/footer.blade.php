<footer class="main-footer">
    <strong>Copyright &copy; 2017 <a href="https://marthaservices.com">MARTHA</a>.</strong> All rights
    reserved.
</footer>