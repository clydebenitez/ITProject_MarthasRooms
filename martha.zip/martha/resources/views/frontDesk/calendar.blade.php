@extends('frontDesk.main')

@section('content')
    <section class="content-header">
      <h1>
        Booking Calendar
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Booking Calendar</li>
      </ol>
        
    </section>

    <!-- Main content -->
  <section class="content">
        <!-- /.col -->
    <div class="row">
      <div class="col-md-9">
        <div class="box box-primary">
            <div class="box-body no-padding">
            <!-- THE CALENDAR -->
            <div id="calendar"></div>
            </div>
              <!-- /.box-body -->
        </div>
            <!-- /. box -->
      </div>
    </div>
        <!-- /.col -->
</section>


@stop