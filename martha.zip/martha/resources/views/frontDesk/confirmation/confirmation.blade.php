@extends('frontDesk.main') 
@section('content')
<section class="content-header">
    <h1>
        Confirmed
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Confirmed</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-default">
                <div class="box-body">

                    <table id="tbl" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Lastname</th>
                                <th>Firstname</th>
                                <th>Check-IN</th>
                                <th>Check-OUT</th>
                                <th>Room Acquired</th>
                                <th>Status</th>
                                <th>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            @if(count($reservation) > 0)
                            
                                @foreach($reservation as $rowReserve)
            
                                    @if($rowReserve->status == 'accepted')
                                        <tr>
                                            <td>{{$rowReserve->guest->gLastname}}</td>
                                            <td>{{$rowReserve->guest->gFirstname}}</td>
                                            <td>{{$rowReserve->checkIn}}</td>
                                            <td>{{$rowReserve->checkOut}}</td>
                                            <td>{{$rowReserve->roomTypes->roomType}}</td>
                                            <td></td>
                                            <td style="text-align:center">
                                                <button class="btn btn-info btn-xs" data-toggle="modal" data-target="#see"><i class="fa fa-user"></i>
                                                </button>
                                                
                                            </td>
                                        </tr>
                                    @endif
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</section>
@stop