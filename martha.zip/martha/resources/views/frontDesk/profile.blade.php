@extends('frontDesk.main')

@section('content')
     <section class="content-header">
      <h1>
        Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Profile</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-sm-12">
        <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Edit Profile</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
            
              <form role="form" method="post">
                <div class="box-body">
                  @foreach($task as $tasks)
                  <div class="form-group">
                    <div class="row">
                      <div class = "col-sm-6">
                        <label>Firstname</label>
                        <input type="text" class="form-control" value='{{$tasks->Firstname}}'>
                      </div> 
                      <div class = "col-sm-6">
                        <label>Lastname</label>
                        <input type="text" class="form-control" value='{{$tasks->Lastname}}'>
                      </div>
                    </div>
                   
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class = "col-sm-6">
                        <label>Email</label>
                        <input type="email" class="form-control" value='{{$tasks->email}}'>
                      </div> 
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6">
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-danger">
                            Change Password
                        </button>
                      </div>
                    </div>
                   
                  </div>
                  
                </div>
                <!-- /.box-body -->
                @endforeach
                <div class="box-footer">
                  <div class="form-group">
                    <div class="row">
                        <div class = "col-lg-11">
                            <a href = '/index'><button type="button" class="btn btn-danger btn-md">Cancel</button></a>
                        </div>
                        <div class = "col-lg-1">
                            <button type="submit" class="btn btn-success btn-md">Save</button>
                        </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
      </div>
    </section>
            
            
            
    <div class="modal modal-warning fade" id="modal-warning">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Warning Modal</h4>
                </div>
                <div class="modal-body">
                    <p>One fine body&hellip;</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-outline">Save changes</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
    
    
    

@stop