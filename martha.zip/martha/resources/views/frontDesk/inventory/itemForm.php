<div class="form-group">
    <label for="itemName">Item Name</label>
    <input type="text" class="form-control" name="itemName" id="itemName" autocomplete="off" autofocus>
</div>

<div class="form-group">
    <label for="quantity">Quantity</label>
    <input type="text" class="form-control" name="quantity" id="quantity" autocomplete="off">

</div>

<div class="form-group">
    <label for="des">Description</label>
    <textarea name="description" id="des" cols="20" rows="5" id='des' class="form-control" autocomplete="off"></textarea>
</div>