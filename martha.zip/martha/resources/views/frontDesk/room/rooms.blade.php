@extends('frontDesk.main') @section('content')

<section class="content-header">
	<h1>
		Rooms
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li class="active">Rooms</li>
	</ol>
</section>

<section class="content">
	<div class="box box-info">
		<div class="box-header with-border">
			<div class="col-xs-12">
				<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-primary">
					  <i class="fa fa-plus "></i> Add Room
			</button>
			</div>
		</div>
		<div class="box-body">
			@if(count($rmType) > 0) 
			@foreach($rmType as $row)

			<div class="col-lg-3 col-xs-6">
				<!-- small box -->
				<div class="small-box bg-blue">
					<div class="inner">
						<h3>150</h3>
						<p>{{$row->roomType}}</p>
					</div>
					<div class="icon">
						<i class="fa fa-user"></i>
					</div>
					<a href='/listRoom' class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				</div>
			</div>

			@endforeach 
			@endif
		</div>
	</div>
	<!-- /.row -->
</section>

@stop
