<div class="form-group">
    <label for="roomType">Room Type</label>
    <input type="text" class="form-control" name="roomType" id="roomType" autocomplete="off" autofocus>

</div>

<div class="form-group">
    <label for="location">Location</label>
    <input type="text" class="form-control" name="location" id="location" autocomplete="off">

</div>

<div class="form-group">
    <label for="capacity">Room Capacity</label>
    <input type="number" min="1" class="form-control" name="capacity" id="capacity" value ="1" autocomplete="off" >
</div>

<div class="form-group">
    <label for="max">Room Max Capacity</label>
    <input type="number" min="1" class="form-control" name="max" id="max" value ="1" autocomplete="off">

</div>

<div class="form-group">
    <label for="price">Room Price</label>
    <div class="input-group">
        <span class="input-group-addon">PHP</span>
        <input type="number" min="1" class="form-control" name="price" id="price" autocomplete="off" >
    </div>
    

</div>
