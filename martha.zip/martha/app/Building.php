<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Building extends Model
{
    public function roomInfo()
    {
       return $this->hasMany('App\Room', 'room_id' , 'id');  
    } 
}
