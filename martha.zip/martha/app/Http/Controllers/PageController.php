<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\RoomType;

class PageController extends Controller
{
    public function dashboard(){
        $type = RoomType::all();
        return view('frontDesk.index', compact('type'));
    } 
    
    public function login(){
        return view('frontDesk.welcome');
    } 
    
    public function booking(){
        return view('frontDesk.booking');
    }
    
    public function calendar(){
        return view('frontDesk.calendar');
    }  
    
    public function rooms(){
        return view('frontDesk.rooms');
    }
    
    public function harvard(){
        return view('frontDesk.rm-harvard');
    }
    
    public function princeton(){
        return view('frontDesk.rm-princeton');
    }
    
    public function wharton(){
        return view('frontDesk.rm-wharton');
    }
    
    public function profile(){
        return view('frontDesk.profile');
    }
}
