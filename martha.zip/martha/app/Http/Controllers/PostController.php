<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Reservation;




class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reservation = Reservation::all();
    
        return view('frontDesk.reservation.reservation', compact('reservation'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('posts.create',  ['rooms'=>Room::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validate the data
        $this->validate($request, array(
            'gFirstName' => 'required',
            'gMiddleName' => 'required',
            'gLastName' => 'required',
            'address' => 'required',
            'contactNumber' => 'required',
            'emailAddress' => 'required',
            'rmType' => 'required',
            'dateArrival' => 'required',
            'dateDeparture' => 'required',
            'adultNum' => 'required',
            'childrenNum' => 'required'
        ));
        
        //store in the database
        $post = new Post;
        
        $post->gFirstName = $request->gFirstName;
        $
        $post->gMiddleName = $request->gMiddleName;
        $post->gLastName = $request->gLastName;
        $post->Address = $request->Address;+
        $post->contactNumber = $request->contactNumber;
        $post->emailAddress = $request->emailAddress;
        $post->rmType = $request->rmType;
        $post->dateArrival = $request->dateArrival;
        $post->dateDeparture = $request->dateDeparture;
        $post->adultNum = $request->adultNum;
        $post->childrenNum = $request-> childrenNum;
        
        $post->save();
        
        return redirect()->route('posts.show', $post->id);
            
        
        //redirect to another page
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $reservation = Reservation::find($id)->with('guest')->get();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
