<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoomType extends Model
{
    protected $table = 'room_types';
    
    protected $fillable = [
        'roomType',
        'Location',
        'roomCapacity',
        'roomMaxCapacity',
    ];
    
    public function room()
    {
        return $this->hasMany('App\Room');  
    }
    
    
    public function reservations()
    {
        return $this->hasMany('App\Reservation');
    }
   
}
