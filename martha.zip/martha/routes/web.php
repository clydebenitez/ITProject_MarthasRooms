<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/index', 'PageController@dashboard');

Route::get('/booking', 'PageController@booking');

Route::get('/calendar', 'PageController@calendar');

Route::get('/harvard', 'PageController@harvard');

Route::get('/princeton', 'PageController@princeton');

Route::get('/wharton', 'PageController@wharton');



Route::resource('guest','GuestController');
Route::resource('room', 'RoomsController');
Route::resource('reservation', 'ReservationController');
Route::resource('confirmation', 'ConfirmationController');





Route::get('/listRoom', 'RoomsController@passID');



Auth::routes();

Route::get('/', 'HomeController@index')->name('home');

Route::group(['middleware' => ['web' => 'auth']], function(){
    
    Route::get('/', function(){
        if(Auth::user()->admin == 0)
        {
            
            
            return view('frontDesk.index', compact('type'));
            
        }
        else
        {
          return view('home');  
        }
    });
});
